//
//  Data.swift
//  zt
//
//  Created by Sicco Dwars on 17-04-16.
//  Copyright © 2016 Martijn Dwars. All rights reserved.
//

import Foundation

class DataSourceTestMode : NSObject {
    var Noise : Float = 0.0
    var Chirp : Float = 0.0
    var ChirpFrom : Float = 0.01
    var ChirpTo : Float = 0.8
    var ChirpIn : Float = 0.5
    var Trapez : Float = 0.0
    var TrapezPeriod : Float = 0.1
    var TrapezRamp : Float = 0.5

    var NewValues : Bool = true
}

class DataSourceWobbleSteering : NSObject {
    var Amplitude : Float = 0.0
    var Offset : Float = 0.0
 
    var NewValues : Bool = true
}

class DataSourceDownLinking : NSObject {
    var Amplitude : Float = 0.5
    var Filter : Float = 0.5
    var DataRate : Float = 0.2
    var Message : String = ""
    var MessageLength : UInt16 = 0
    var QuitSending : Bool = false
    var StartSending : Bool = false;
    var NewValues : Bool = true
}

class DataSourcePlot : NSObject {
    let Npoints = 512
    var plot_cycles : Int = 0
    var chart_y1 = [Double]()
    var chart_y2 = [Double]()
    var chart_y3 = [Double]()
    var chart_y4 = [Double]()
    var stringChartX = [String]()
}

class DataSourceAuthority : NSObject {
    var TheAuthority : UInt16 = 0
}