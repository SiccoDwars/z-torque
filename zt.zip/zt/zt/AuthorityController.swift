//
//  AuthorityController.swift
//  zt
//
//  Created by Sicco Dwars on 27-05-16.
//  Copyright © 2016 Martijn Dwars. All rights reserved.
//

//import Foundation
import UIKit

class AuthorityController: UIViewController,UIPickerViewDataSource,UIPickerViewDelegate {

    @IBOutlet weak var PIN_editbox: UITextField!
    @IBOutlet weak var AuthPicker: UIPickerView!
    
    var model: DataSourceAuthority?
    let pickerData = ["Level 0, safe","Level 1 (RPM set & Torque Limit override)","Level 2 - also CW, only use if no-one is on the drill floor!"]
    override func viewDidLoad() {
        
         super.viewDidLoad()
        
        AuthPicker.dataSource = self
        AuthPicker.delegate = self
        
        model?.TheAuthority = 0
        
    }
    
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerData.count
    }
    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pickerData[row]
    }
    
    func pickerView(pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        if (PIN_editbox.text == "ACCEPT") {
            model?.TheAuthority = UInt16(row) }
        else {
            model?.TheAuthority = 0 }
        
    }

}
