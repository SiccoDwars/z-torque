//
//  ViewController.swift
//  zt
//
//  Created by Martijn Dwars on 02/04/16.
//  Copyright © 2016 Martijn Dwars. All rights reserved.
//

import UIKit
import CocoaAsyncSocket
import Charts

class ViewController: UIViewController {
    var pico = Pico()
    var dataSourceTestMode = DataSourceTestMode()
    var dataSourceWobbleSteering = DataSourceWobbleSteering()
    var dataSourceDownLinking = DataSourceDownLinking()
    var dataSourcePlot = DataSourcePlot()
    var dataSourceAuthority = DataSourceAuthority()
    var busyPlotting:Bool = true
 
    let IPaddress_seeting_file = "ip_zt_file.txt" //this is the file. we will write to and read from it
    
    @IBOutlet weak var Text2: UITextView!
    
    @IBOutlet weak var bJ: UITextField!
    
    @IBOutlet weak var C2: UITextField!
    @IBOutlet weak var FIR_C2: UITextField!
    
    
    @IBOutlet weak var C3: UITextField!
    
    @IBOutlet weak var FIR_C3: UITextField!
    
    @IBOutlet weak var M: UITextField!
    
    @IBOutlet weak var FIR_M: UITextField!
    
    
    @IBOutlet weak var SLLP: UITextField!
    
    @IBOutlet weak var RPM: UILabel!
    
    @IBOutlet weak var Torque: UILabel!
    
    @IBOutlet weak var Zramped: UILabel!
    
    @IBOutlet weak var SlideRPMset: UISlider!
    @IBOutlet weak var RPMsetTextBox: UILabel!
    @IBOutlet weak var OnOffRPMset: UISwitch!
    @IBOutlet weak var SlideTRQlim: UISlider!
    @IBOutlet weak var TRQlimTextBox: UILabel!
    @IBOutlet weak var OnOffTRQlim: UISwitch!
    @IBOutlet weak var SliderZ: UISlider!
    @IBOutlet weak var OnOffZ: UISwitch!
    @IBOutlet weak var ZsetTextBox: UILabel!
    
    @IBOutlet weak var IPaddressTextBox: UITextField!
    
    @IBOutlet weak var CW_override: UISwitch!
    
    @IBOutlet weak var CW_b0: UISwitch!
    @IBOutlet weak var CW_b1: UISwitch!
    @IBOutlet weak var CW_b2: UISwitch!
    @IBOutlet weak var CW_b3: UISwitch!
    @IBOutlet weak var CW_b4: UISwitch!
    @IBOutlet weak var CW_b5: UISwitch!
    @IBOutlet weak var CW_b6: UISwitch!
    @IBOutlet weak var CW_b7: UISwitch!
    
    @IBOutlet weak var CW_b8: UISwitch!
    @IBOutlet weak var CW_b9: UISwitch!
    @IBOutlet weak var CW_b10: UISwitch!
    @IBOutlet weak var CW_b11: UISwitch!
    @IBOutlet weak var CW_b12: UISwitch!
    @IBOutlet weak var CW_b13: UISwitch!
    @IBOutlet weak var CW_b14: UISwitch!
    @IBOutlet weak var CW_b15: UISwitch!
    
    @IBOutlet weak var Bbb: UISwitch!
    
    @IBOutlet weak var ToolFaceIndicator: UIProgressView!
    @IBOutlet weak var LabelToolFaceValue: UILabel!
    
    @IBOutlet weak var RPMcomProgressBar: UIProgressView!
    
    @IBOutlet weak var TextLabelTelemetryStatus: UILabel!
    @IBOutlet weak var TexboxAuthorityLevel: UITextField!
    
    
    @IBOutlet weak var HeartBeatIndicator: UISwitch!
    
    var cycles:UInt32 = 0
    //var Authority:UInt16 = 0
    
   
    @IBOutlet weak var chartView: LineChartView!;
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Swift 2.2 selector syntax
        _ = NSTimer.scheduledTimerWithTimeInterval(0.25, target: self, selector: #selector(ViewController.update), userInfo: nil, repeats: true)
        _ = NSTimer.scheduledTimerWithTimeInterval(0.5, target: self, selector: #selector(ViewController.doPlot), userInfo: nil, repeats: true)
        
        
        if let dir = NSSearchPathForDirectoriesInDomains(NSSearchPathDirectory.DocumentDirectory, NSSearchPathDomainMask.AllDomainsMask, true).first {
            let path = NSURL(fileURLWithPath: dir).URLByAppendingPathComponent(IPaddress_seeting_file)
            
            //reading
            do {
                let text2 = try NSString(contentsOfURL: path, encoding: NSUTF8StringEncoding)
                IPaddressTextBox.text = text2 as String
            }
            catch {
                let text = "192.168.0.1" // make default file if it didn't exist yet
                do {
                    try text.writeToURL(path, atomically: false, encoding: NSUTF8StringEncoding)
                }
                catch {/* error handling here */}
            }
        }
        
        
        
        //Chart
        chartView.descriptionText = "";
        chartView.noDataTextDescription = "You need to provide data for the chart.";
        
        chartView.drawBordersEnabled = true;
        
        chartView.leftAxis.drawAxisLineEnabled = false;
        chartView.leftAxis.drawGridLinesEnabled = false;
        chartView.rightAxis.drawAxisLineEnabled = false;
        chartView.rightAxis.drawGridLinesEnabled = false;
        chartView.xAxis.drawAxisLineEnabled = false;
        chartView.xAxis.drawGridLinesEnabled = false;
        
        chartView.drawGridBackgroundEnabled = false;
        chartView.dragEnabled = true;
        chartView.setScaleEnabled(true);
        chartView.pinchZoomEnabled = false;
        
        chartView.autoScaleMinMaxEnabled = true
        
        
        //chartView.legend.position = ChartLegendPositionRightOfChart;

        for i in 0 ..< dataSourcePlot.Npoints {
            dataSourcePlot.stringChartX.append (String(format:"%1.1f", (Double(i)/10))) }
        
        for i in 0 ..< dataSourcePlot.Npoints {
            dataSourcePlot.chart_y1.append (50+100*sin(Double(i)/100))
            dataSourcePlot.chart_y2.append (50+100*cos(Double(i)/100))
            dataSourcePlot.chart_y3.append (60+100*sin(Double(i)/30))
            dataSourcePlot.chart_y4.append (70+100*sin(Double(i)/40))}
    
        setChartData(dataSourcePlot)
        
        busyPlotting = false
    }
    
    func setChartData(dataSourcePlot : DataSourcePlot) {

        var color :NSUIColor
        
        
        // 1 - creating an array of data entries
        var yVals1 : [ChartDataEntry] = [ChartDataEntry]()
        var yVals2 : [ChartDataEntry] = [ChartDataEntry]()
        var yVals3 : [ChartDataEntry] = [ChartDataEntry]()
        var yVals4 : [ChartDataEntry] = [ChartDataEntry]()
        
        var k : Int
        for i in 0 ..< dataSourcePlot.stringChartX.count {
            k = (dataSourcePlot.plot_cycles + i) % dataSourcePlot.Npoints;
            yVals1.append(ChartDataEntry(value: dataSourcePlot.chart_y1[k], xIndex: i))
            yVals2.append(ChartDataEntry(value: dataSourcePlot.chart_y2[k], xIndex: i))
            yVals3.append(ChartDataEntry(value: dataSourcePlot.chart_y3[k], xIndex: i))
            yVals4.append(ChartDataEntry(value: dataSourcePlot.chart_y4[k], xIndex: i))
        }
        
        // 2 - create a data set with our array
        let set1: LineChartDataSet = LineChartDataSet(yVals: yVals1, label: "Quill RPM")
        color = UIColor.greenColor();
        set1.axisDependency = .Left // Line will correlate with left axis values
        set1.setColor(color.colorWithAlphaComponent(0.5)) // our line's opacity is 50%//
        set1.setCircleColor(color) // our circle will be dark red
        set1.lineWidth = 1.0
        set1.circleRadius = 0.0 // the radius of the node circle
        set1.fillAlpha = 65 / 255.0
        set1.fillColor = color
        set1.highlightColor = UIColor.whiteColor()
        set1.drawCircleHoleEnabled = true

        let set2: LineChartDataSet = LineChartDataSet(yVals: yVals2, label: "Quill Torque")
        color = UIColor.redColor();
        set2.axisDependency = .Left // Line will correlate with left axis values
        set2.setColor(color.colorWithAlphaComponent(0.5)) // our line's opacity is 50%
        set2.setCircleColor(color) // our circle will be dark red
        set2.lineWidth = 1.0
        set2.circleRadius = 0.0 // the radius of the node circle
        set2.fillAlpha = 65 / 255.0
        set2.fillColor = color
        set2.highlightColor = UIColor.whiteColor()
        set2.drawCircleHoleEnabled = true
        
        let set3: LineChartDataSet = LineChartDataSet(yVals: yVals3, label: "Airgap Torque")
        color = UIColor.blueColor()
        set3.axisDependency = .Left // Line will correlate with left axis values
        set3.setColor(color.colorWithAlphaComponent(0.5)) // our line's opacity is 50%
        set3.setCircleColor(color) // our circle will be dark red
        set3.lineWidth = 1.0
        set3.circleRadius = 0.0 // the radius of the node circle
        set3.fillAlpha = 65 / 255.0
        set3.fillColor = color
        set3.highlightColor = UIColor.whiteColor()
        set3.drawCircleHoleEnabled = true
        
        let set4: LineChartDataSet = LineChartDataSet(yVals: yVals4, label: "Z")
        color = UIColor.darkGrayColor()
        set4.axisDependency = .Left // Line will correlate with left axis values
        set4.setColor(color.colorWithAlphaComponent(0.5)) // our line's opacity is 50%
        set4.setCircleColor(color) // our circle will be dark red
        set4.lineWidth = 1.0
        set4.circleRadius = 0.0 // the radius of the node circle
        set4.fillAlpha = 65 / 255.0
        set4.fillColor = color
        set4.highlightColor = UIColor.whiteColor()
        set4.drawCircleHoleEnabled = true
        
        //3 - create an array to store our LineChartDataSets
        var dataSets : [LineChartDataSet] = [LineChartDataSet]()
        dataSets.append(set1)
        dataSets.append(set2)
        dataSets.append(set3)
        dataSets.append(set4)
        
        //4 - pass our timeseries in for our x-axis label value along with our dataSets
        let data: LineChartData = LineChartData(xVals: dataSourcePlot.stringChartX, dataSets: dataSets)
        data.setValueTextColor(UIColor.whiteColor())
        
        //5 - finally set our data
        self.chartView.setNeedsDisplay()
        self.chartView.data = data

        busyPlotting = false
        
    }
    
    func ddoPlot()
    {
        self.setChartData(self.dataSourcePlot)
    }
    
    func doPlot() {
        if (!busyPlotting) {
            if (Bbb.on) {
                busyPlotting = true

                let queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)
                dispatch_async(queue) {
                    self.ddoPlot()
                }
                
            }
        }
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        switch segue.identifier! {
            case "testmodeSegue":
                let next = segue.destinationViewController as! NextController
                next.model = dataSourceTestMode
            case "wobbleSegue":
                let wobble = segue.destinationViewController as! WobbleController
                wobble.model = dataSourceWobbleSteering
            case "downlinkSegue":
                let downlink = segue.destinationViewController as! DownlinkController
                downlink.model = dataSourceDownLinking
            case "plotInspectSegue":
                let plotInspect = segue.destinationViewController as! InspectController
                plotInspect.model = dataSourcePlot
            case "authoritySegue":
                let auth = segue.destinationViewController as! AuthorityController
                auth.model = dataSourceAuthority
            default:
                break
        }

    }
    
    @IBAction func quitButtonTochDown(sender: AnyObject) {
      exit(0)
    }
    
    
    // must be internal or public.
    func update() {
        ShowIfConnected()
        Cyclic_Poll_ZT_board ()
     }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func ShowIfConnected(){
        Text2.text = pico.get_status_as_string()
    }
    
    func setBinaryCW (CW : UInt16)

    {
        CW_b0.on = ((CW & 0b0000000000000001) != 0)
        CW_b1.on = ((CW & 0b0000000000000010) != 0)
        CW_b2.on = ((CW & 0b0000000000000100) != 0)
        CW_b3.on = ((CW & 0b0000000000001000) != 0)
        CW_b4.on = ((CW & 0b0000000000010000) != 0)
        CW_b5.on = ((CW & 0b0000000000100000) != 0)
        CW_b6.on = ((CW & 0b0000000001000000) != 0)
        CW_b7.on = ((CW & 0b0000000010000000) != 0)
        CW_b8.on = ((CW & 0b0000000100000000) != 0)
        CW_b9.on = ((CW & 0b0000001000000000) != 0)
        CW_b10.on = ((CW & 0b0000010000000000) != 0)
        CW_b11.on = ((CW & 0b0000100000000000) != 0)
        CW_b12.on = ((CW & 0b0001000000000000) != 0)
        CW_b13.on = ((CW & 0b0010000000000000) != 0)
        CW_b14.on = ((CW & 0b0100000000000000) != 0)
        CW_b15.on = ((CW & 0b1000000000000000) != 0)
    }
    
    func GetBinaryCW () -> UInt16
    {
        var r:UInt16 = 0
        
        if (CW_b0.on) {
            r += 0b0000000000000001 }
        if (CW_b1.on) {
            r += 0b0000000000000010 }
        if (CW_b2.on) {
            r += 0b0000000000000100 }
        if (CW_b3.on) {
            r += 0b0000000000001000 }
        if (CW_b4.on) {
            r += 0b0000000000010000 }
        if (CW_b5.on) {
            r += 0b0000000000100000 }
        if (CW_b6.on) {
            r += 0b0000000001000000 }
        if (CW_b7.on) {
            r += 0b0000000010000000 }
        if (CW_b8.on) {
            r += 0b0000000100000000 }
        if (CW_b9.on) {
            r += 0b0000001000000000 }
        if (CW_b10.on) {
            r += 0b0000010000000000 }
        if (CW_b11.on) {
            r += 0b0000100000000000 }
        if (CW_b12.on) {
            r += 0b0001000000000000 }
        if (CW_b13.on) {
            r += 0b0010000000000000 }
        if (CW_b14.on) {
            r += 0b0100000000000000 }
        if (CW_b15.on) {
            r += 0b1000000000000000 }
        
        return r
    }
    
    func Cyclic_Poll_ZT_board (){
        var RPM_set: Double
        var RPM_act: Double
        var Torque_act: Double
        var Torque_mot: Double
        var Torque_lim: Double
        var Z_ref: Double = 0.0
        var Z: Double
        var Z_recip: Double = 99999.0
        var OnOffs: UInt16 = 0
        var CW: UInt16 = 1;
        var RPMset: UInt16
        var TRQlim: UInt16
        var Z_requested: UInt16
        var Zreq: Double
        var Zreq_recip: Double = 99999.0
        var st:String = ""
        
        let Authority = dataSourceAuthority.TheAuthority
        
        TexboxAuthorityLevel.text = String(stringInterpolationSegment: UInt32(Authority))
 
        if (pico.HeartBeater == 1) {
            OnOffs += 0b100000000}
        
        if (CW_override.on && (Authority >= 2)){
            OnOffs += 0b00010000}
        else {
            CW_override.on = false
        }

        if (OnOffRPMset.on  && (Authority >= 1)){
            OnOffs += 0b00100000}
        else {
            OnOffRPMset.on = false
        }
        
        if (OnOffTRQlim.on  && (Authority >= 1)){
            OnOffs += 0b01000000}
        else {
            OnOffTRQlim.on = false
        }
        
        if (OnOffZ.on){
            OnOffs += 0b10000000}
        
        if (pico.isConnectedOK){
            self.view.backgroundColor = UIColor.greenColor() }
        else {
            self.view.backgroundColor = UIColor.redColor()}

        
        RPM_act = pico.Nref_act *  (Double(pico.RPMact)/16384) / pico.Ngear
        Torque_act = pico.Tref * (Double(pico.TorqueActPipe)/16384) * pico.Ngear
        Torque_mot = pico.Tref * (Double(pico.TorqueActAirgap)/16384) * pico.Ngear
        
        if (pico.Tref>0){
            Z_ref = (pico.Nref_act * (3.1415927 / 30) * 8.0) / (pico.Tref * pico.Ngear * pico.Ngear)
        }

        CW = GetBinaryCW ()
    
        RPMset = UInt16 (SlideRPMset.value * 16384.0)
        TRQlim = UInt16 (SlideTRQlim.value * 16384.0)
        Z_requested = UInt16(SliderZ.value * 16384.0)
        
        RPM_set = Double(pico.Nref_set) *  (Double(RPMset)/16384) / pico.Ngear;
        Torque_lim = Double(pico.Tref) * (Double(TRQlim)/16384) * pico.Ngear;
        
        RPMsetTextBox.text = String(stringInterpolationSegment: UInt32(RPM_set))
        TRQlimTextBox.text = String(stringInterpolationSegment: UInt32(Torque_lim))

        Zreq = ((Double(Z_requested) * Z_ref) / 16384.0)
        if (Zreq>0.0){
            Zreq_recip = 1.0 / Zreq}
       
        ZsetTextBox.text = "1/"+String(stringInterpolationSegment: UInt32(Zreq_recip))
        
//        var NewValues:Bool = false
        
        if (dataSourceTestMode.NewValues)
        {
              pico.Yy(UInt16(2000*dataSourceTestMode.Noise), ChirpAmpl: UInt16(2000*dataSourceTestMode.Chirp), ChirpFreqFrom: UInt16(500*dataSourceTestMode.ChirpFrom), ChirpFreqTo:UInt16(500*dataSourceTestMode.ChirpTo), ChirpPeriod:UInt16(60000*dataSourceTestMode.ChirpIn), T_Chirp:UInt16(0), TrapAmpl:UInt16(2000*dataSourceTestMode.Trapez), TrapStep:UInt16(100*dataSourceTestMode.TrapezRamp), TrapPeriodHi:UInt16(6000*dataSourceTestMode.TrapezPeriod), TrapPeriodLow:UInt16(6000*dataSourceTestMode.TrapezPeriod))
            dataSourceTestMode.NewValues = false
        }
        else
        {
            if (dataSourceWobbleSteering.NewValues) {
                pico.WobbleSteerCommand(UInt16(2000*dataSourceWobbleSteering.Amplitude), Phase:UInt16(1024*dataSourceWobbleSteering.Offset))
                dataSourceWobbleSteering.NewValues = false
            }
            else {
                if (dataSourceDownLinking.NewValues) {
                    pico.DownLinkSetup (UInt16(2000*dataSourceDownLinking.Amplitude), BitTime:UInt16(200*dataSourceDownLinking.DataRate*10), Filter:UInt16(12*dataSourceDownLinking.Filter))
                    dataSourceDownLinking.NewValues = false
                }
                else {
                    if (dataSourceDownLinking.QuitSending){
                        pico.DownLinkQuit()
                        dataSourceDownLinking.QuitSending = false
                    }
                    else
                    {
                        if (dataSourceDownLinking.StartSending){
                            pico.DownLinkCommand(dataSourceDownLinking.Message, MessageLength: dataSourceDownLinking.MessageLength)
                            dataSourceDownLinking.StartSending = false
                        }
                        else {
                            if (((cycles & 1) == 0) || (pico.Nref_set==0)){
                                if ((cycles & 2) == 0){
                                    if (pico.Nref_set == 0) {
                                        pico.Ww11()
                                    }
                                    else {
                                        pico.Ww20(pico.address_timeDate, Nwords:3)
                                    }
                                }
                                else {
                                    pico.Ww21()
                                }
                            }
                            else{
                                pico.Xx(OnOffs, CW: CW, RPMset: RPMset, TRQlim: TRQlim, Z_req: Z_requested);
                            }
                        }
                    }
                }
            }
            cycles += 1
        }
        
        
        HeartBeatIndicator.on = (pico.HeartBeater != 0)
        
        
        if (!CW_override.on){
            setBinaryCW (pico.CW)}
        
        RPMcomProgressBar.progress = Float(pico.RPMcommanded)/16384.0
        
        if (!OnOffRPMset.on){
            SlideRPMset.value = Float(pico.RPMset)/16384.0}
        
        if (!OnOffTRQlim.on){
            SlideTRQlim.value = Float(pico.TRQlim)/16384.0}
        
        if (!OnOffZ.on){
            SliderZ.value = Float(pico.Z_ramped)/16384.0}
        
        ToolFaceIndicator.progress = Float(pico.ToolFace) / 1024
        LabelToolFaceValue.text = NSString(format:"%1.1f", (360.0*Float(pico.ToolFace)/1024.0)) as String
        
        Z = ((Double(pico.Z_ramped) * Z_ref) / 16384.0)
        if (Z>0.0){
            Z_recip = 1.0 / Z}

        RPM.text = NSString(format:"%1.1f", RPM_act) as String
        Torque.text = NSString(format:"%1.3f", Torque_act/1000.0) as String
        Zramped.text = NSString(format:"%1.1f", Z_recip) as String
        
        st = pico.TimeDateString() as String
        st += NSString(format:"telemetry at bit # %d of %d", pico.DownLinkBitPosition, 16+12*(2+dataSourceDownLinking.MessageLength)) as String
        TextLabelTelemetryStatus.text = st
        
        let i = Int(cycles) % dataSourcePlot.Npoints
        dataSourcePlot.chart_y1[i] = RPM_act
        dataSourcePlot.chart_y2[i] = 4 * Torque_act / 1000.0
        dataSourcePlot.chart_y3[i] = 4 * Torque_mot / 1000.0
        dataSourcePlot.chart_y4[i] = Double(pico.Z_ramped) / 64
        dataSourcePlot.plot_cycles = i+1;
 //       if (Bbb.on) {
 //                self.setChartData(self.dataSourcePlot)
 //       }
        self.chartView.setNeedsDisplay()
        
        if (pico.new_settings_read_from_ZTboard)
        {
            C2.text = NSString(format:"%d", pico.Filt_C2) as String
            C3.text = NSString(format:"%d", pico.Filt_C3) as String
            M.text = NSString(format:"%d", pico.Filt_M) as String
            FIR_C2.text = NSString(format:"%d", pico.FIR_C2) as String
            FIR_C3.text = NSString(format:"%d", pico.FIR_C3) as String
            FIR_M.text = NSString(format:"%d", pico.FIR_M) as String
            bJ.text = NSString(format:"%d", pico.bJ) as String
            SLLP.text = NSString(format:"%d", pico.SLLP) as String
            pico.new_settings_read_from_ZTboard = false;
        }
    }
    
    
    @IBAction func connectTapped(sender: AnyObject) {
    //    print("Connect button tapped!")
        
        dataSourceAuthority.TheAuthority = 0
        
        pico.connect(IPaddressTextBox.text!)
     }
    
    @IBAction func disconnectTapped(sender: AnyObject) {
        
     //   print("Disconnect button tapped!")
        if (pico.isConnectedOK) {
            if let dir = NSSearchPathForDirectoriesInDomains(NSSearchPathDirectory.DocumentDirectory, NSSearchPathDomainMask.AllDomainsMask, true).first {
                let path = NSURL(fileURLWithPath: dir).URLByAppendingPathComponent(IPaddress_seeting_file)
                
                let text = IPaddressTextBox.text!
                do {
                    try text.writeToURL(path, atomically: false, encoding: NSUTF8StringEncoding)
                }
                catch {/* error handling here */}
            }

        }
        pico.disconnect()
     }
    @IBAction func sendTapped(sender: AnyObject) {
    //    print("Send button tapped!")
        var C2_asUInt16: UInt16
        var C3_asUInt16: UInt16
        var M_asUInt16: UInt16
        var C2_FIR_asUInt16: UInt16
        var C3_FIR_asUInt16: UInt16
        var M_FIR_asUInt16: UInt16
 
        var J_asUInt16: UInt16
        var Z_asUInt16: UInt16
        var SLLP_asUInt16: UInt16
        
        C2_asUInt16 = UInt16(C2.text!)!
        C2_FIR_asUInt16 = UInt16(FIR_C2.text!)!
        C3_asUInt16 = UInt16(C3.text!)!
        C3_FIR_asUInt16 = UInt16(FIR_C3.text!)!
        M_asUInt16 = UInt16(M.text!)!
        M_FIR_asUInt16 = UInt16(FIR_M.text!)!
        J_asUInt16 = UInt16 (bJ.text!)!
        Z_asUInt16 = UInt16 (16384.0 * SliderZ.value)
        SLLP_asUInt16 = UInt16 (SLLP.text!)!
        
        pico.send(C2_FIR_asUInt16, b: C3_FIR_asUInt16, c: M_FIR_asUInt16, d: C2_asUInt16,  e: C3_asUInt16, f: M_asUInt16, g: J_asUInt16, h:Z_asUInt16, i:SLLP_asUInt16)
    }

}

