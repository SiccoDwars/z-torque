//
//  WobbleSteerController.swift
//  zt
//
//  Created by Sicco Dwars on 17-04-16.
//  Copyright © 2016 Martijn Dwars. All rights reserved.
//

import UIKit

class WobbleController: UIViewController {
    
    var model: DataSourceWobbleSteering?

    
    @IBOutlet weak var SlideWobbleAmplitude: UISlider!
    @IBOutlet weak var SlideWobbleOffset: UISlider!
    @IBOutlet weak var TextBoxWobbleAmplitude: UITextField!
    @IBOutlet weak var TextBoxWobbleOffset: UITextField!
    
    
override func viewDidLoad() {
    super.viewDidLoad()
    SlideWobbleAmplitude.value = self.model!.Amplitude
    SlideWobbleOffset.value = self.model!.Offset
    
    doSlideChanged()
}

@IBAction func SlideChanged(sender: AnyObject) {
    doSlideChanged()
}

func doSlideChanged() {
    self.model!.Offset = SlideWobbleOffset.value
    self.model!.Amplitude = SlideWobbleAmplitude.value
    
    TextBoxWobbleAmplitude.text = String(stringInterpolationSegment: UInt32(2000 * self.model!.Amplitude))
    TextBoxWobbleOffset.text = String(stringInterpolationSegment: UInt32(360 * self.model!.Offset))
    
    self.model!.NewValues = true
}
}
