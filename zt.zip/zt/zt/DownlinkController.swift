//
//  DownlinkController.swift
//  zt
//
//  Created by Sicco Dwars on 17-04-16.
//  Copyright © 2016 Martijn Dwars. All rights reserved.
//

import UIKit

class DownlinkController: UIViewController {
    var model: DataSourceDownLinking?
    
    @IBOutlet weak var SlideDownlinkAmplitude: UISlider!
    @IBOutlet weak var SlideDownLinkDataRate: UISlider!
    @IBOutlet weak var SlideDownLinkFilter: UISlider!
    
    @IBOutlet weak var TextBoxDownLinkAmplitude: UITextField!
    @IBOutlet weak var TextBoxDownLinkDataRate: UITextField!
    @IBOutlet weak var TextBoxDownLinkFilter: UITextField!
    
    @IBOutlet weak var TextBoxDownLinkMessage: UITextField!
    
    @IBOutlet weak var LabelDownLinkStatus: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        SlideDownlinkAmplitude.value = self.model!.Amplitude
        SlideDownLinkDataRate.value = self.model!.DataRate
        SlideDownLinkFilter.value = self.model!.Filter
        TextBoxDownLinkMessage.text = self.model!.Message
        
        doSlideChanged()
    }
    
    @IBAction func SlideChanged(sender: AnyObject) {
        doSlideChanged()
    }
    
    @IBAction func SendMessageButtonPressed(sender: AnyObject) {
        self.model!.Message = TextBoxDownLinkMessage.text!
        self.model!.MessageLength = UInt16(self.model!.Message.lengthOfBytesUsingEncoding(NSUTF8StringEncoding))
        if ((self.model!.MessageLength & 1) != 0){
            self.model!.MessageLength += 1
            self.model!.Message += " "
        }
        self.model!.StartSending = true
    }
    
    @IBAction func QuitSendingButtonPressed(sender: AnyObject) {
        self.model!.QuitSending = true
    }
    func doSlideChanged() {

        self.model!.Amplitude = SlideDownlinkAmplitude.value
        self.model!.DataRate  = SlideDownLinkDataRate.value
        self.model!.Filter = SlideDownLinkFilter.value
       
        TextBoxDownLinkAmplitude.text = String(stringInterpolationSegment: UInt32(2000 * self.model!.Amplitude))
        TextBoxDownLinkDataRate.text = NSString(format:"%1.1f", 10 * self.model!.DataRate) as String
        TextBoxDownLinkFilter.text = String(stringInterpolationSegment: UInt32(12 * self.model!.Filter))
        
        self.model!.NewValues = true
    }

}