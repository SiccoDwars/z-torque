//
//  InspectController.swift
//  zt
//
//  Created by Sicco Dwars on 27-05-16.
//  Copyright © 2016 Martijn Dwars. All rights reserved.
//

import Foundation
import Charts

class InspectController: UIViewController {

    var model: DataSourcePlot?
   
    
    @IBOutlet weak var chartView: LineChartView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Chart
        chartView.descriptionText = "";
        chartView.noDataTextDescription = "You need to provide data for the chart.";
        
        chartView.drawBordersEnabled = true;
        
        chartView.leftAxis.drawAxisLineEnabled = false;
        chartView.leftAxis.drawGridLinesEnabled = false;
        chartView.rightAxis.drawAxisLineEnabled = false;
        chartView.rightAxis.drawGridLinesEnabled = false;
        chartView.xAxis.drawAxisLineEnabled = false;
        chartView.xAxis.drawGridLinesEnabled = false;
        
        chartView.drawGridBackgroundEnabled = false;
        chartView.dragEnabled = true;
        chartView.setScaleEnabled(true);
        chartView.pinchZoomEnabled = false;
        
        chartView.autoScaleMinMaxEnabled = true
        
        setChartData(model!)
        
    }
    
    func setChartData(dataSourcePlot : DataSourcePlot) {
        
        var color :NSUIColor
        
        
        // 1 - creating an array of data entries
        var yVals1 : [ChartDataEntry] = [ChartDataEntry]()
        var yVals2 : [ChartDataEntry] = [ChartDataEntry]()
        var yVals3 : [ChartDataEntry] = [ChartDataEntry]()
        var yVals4 : [ChartDataEntry] = [ChartDataEntry]()

        var k : Int
        for i in 0 ..< dataSourcePlot.stringChartX.count {
            k = (dataSourcePlot.plot_cycles + i) % dataSourcePlot.Npoints;
            yVals1.append(ChartDataEntry(value: dataSourcePlot.chart_y1[k], xIndex: i))
            yVals2.append(ChartDataEntry(value: dataSourcePlot.chart_y2[k], xIndex: i))
            yVals3.append(ChartDataEntry(value: dataSourcePlot.chart_y3[k], xIndex: i))
            yVals4.append(ChartDataEntry(value: dataSourcePlot.chart_y4[k], xIndex: i))
        }
        // 2 - create a data set with our array
        let set1: LineChartDataSet = LineChartDataSet(yVals: yVals1, label: "Quill RPM")
        color = UIColor.greenColor();
        set1.axisDependency = .Left // Line will correlate with left axis values
        set1.setColor(color.colorWithAlphaComponent(0.5)) // our line's opacity is 50%//
        set1.setCircleColor(color) // our circle will be dark red
        set1.lineWidth = 1.0
        set1.circleRadius = 0.0 // the radius of the node circle
        set1.fillAlpha = 65 / 255.0
        set1.fillColor = color
        set1.highlightColor = UIColor.whiteColor()
        set1.drawCircleHoleEnabled = true
        
        let set2: LineChartDataSet = LineChartDataSet(yVals: yVals2, label: "Quill Torque")
        color = UIColor.redColor();
        set2.axisDependency = .Left // Line will correlate with left axis values
        set2.setColor(color.colorWithAlphaComponent(0.5)) // our line's opacity is 50%
        set2.setCircleColor(color) // our circle will be dark red
        set2.lineWidth = 1.0
        set2.circleRadius = 0.0 // the radius of the node circle
        set2.fillAlpha = 65 / 255.0
        set2.fillColor = color
        set2.highlightColor = UIColor.whiteColor()
        set2.drawCircleHoleEnabled = true
        
        let set3: LineChartDataSet = LineChartDataSet(yVals: yVals3, label: "Airgap Torque")
        color = UIColor.blueColor()
        set3.axisDependency = .Left // Line will correlate with left axis values
        set3.setColor(color.colorWithAlphaComponent(0.5)) // our line's opacity is 50%
        set3.setCircleColor(color) // our circle will be dark red
        set3.lineWidth = 1.0
        set3.circleRadius = 0.0 // the radius of the node circle
        set3.fillAlpha = 65 / 255.0
        set3.fillColor = color
        set3.highlightColor = UIColor.whiteColor()
        set3.drawCircleHoleEnabled = true
    
        let set4: LineChartDataSet = LineChartDataSet(yVals: yVals4, label: "Z")
        color = UIColor.darkGrayColor()
        set4.axisDependency = .Left // Line will correlate with left axis values
        set4.setColor(color.colorWithAlphaComponent(0.5)) // our line's opacity is 50%
        set4.setCircleColor(color) // our circle will be dark red
        set4.lineWidth = 1.0
        set4.circleRadius = 0.0 // the radius of the node circle
        set4.fillAlpha = 65 / 255.0
        set4.fillColor = color
        set4.highlightColor = UIColor.whiteColor()
        set4.drawCircleHoleEnabled = true
        
        //3 - create an array to store our LineChartDataSets
        var dataSets : [LineChartDataSet] = [LineChartDataSet]()
        dataSets.append(set1)
        dataSets.append(set2)
        dataSets.append(set3)
        dataSets.append(set4)
        
        //4 - pass our timeseries in for our x-axis label value along with our dataSets
        let data: LineChartData = LineChartData(xVals: dataSourcePlot.stringChartX, dataSets: dataSets)
        data.setValueTextColor(UIColor.whiteColor())
        
        //5 - finally set our data
        self.chartView.setNeedsDisplay()
        self.chartView.data = data
}
}
